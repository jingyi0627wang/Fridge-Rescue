本版本的“云端”范围是账号注册和跨手机登录，不是冰箱/菜谱同步。

用法：手机 A 点 Sign up 注册；手机 B 点 Log In，输入相同用户名和密码。不需要在手机 B 再注册。用户名忽略首尾空格和大小写，密码保持原样。
两台手机必须安装使用同一 GoogleService-Info.plist 的本项目，并连接网络。Firebase 控制台 Authentication > Sign-in method 必须启用 Email/Password。本版沿用原来 username@freshlings.com 的内部账号格式，不会让原账号失效。

修正：全新手机默认进入登录而不是自动判定需要注册；Firebase 认证状态决定是否已登录；正常启动恢复登录状态；退出会真正调用 Firebase signOut；重复注册已有用户名时提示转去登录；网络错误单独提示。

保留：254 个食材图标、18 个菜谱图标、灰色 Other、加入冰箱只抖两下、所有原有食物/菜谱功能。

测试：本地代码和身份规范化检查已执行，尚未在你的 Firebase 项目上进行两台真机端到端验证。
