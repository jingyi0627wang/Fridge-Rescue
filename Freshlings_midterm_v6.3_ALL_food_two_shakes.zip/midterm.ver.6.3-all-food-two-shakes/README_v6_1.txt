Freshlings v6.1

Based on the supplied midterm.ver.6.0 folder. Firebase login/configuration, project settings and existing storage implementation are retained.
254 named ingredient illustrations + 18 dish illustrations + gray mystery Other category imported.
Add My Recipe uses the labeled dish illustration grid and supports legacy saved icon IDs.
Every newly added food plays exactly two short shakes on its first appearance in Fridge, then remains still. Urgent status no longer causes recurring shaking in Fridge or Today. Reloading previously saved food does not queue an animation. Reduced Motion suppresses it.
Open Midterm.xcodeproj. Original Downloads project preserved.
